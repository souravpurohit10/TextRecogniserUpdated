//
//  ProcessedImageVC.swift
//  TextDetectionPOC
//
//  Created by Sourav Purohit on 18/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import UIKit

var selectedType = "Food"
class ProcessedImageVC: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {

    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var addMoreDetailsButton: UIButton!
    
    @IBOutlet weak var selectCategoryView: UIView!
    
    @IBOutlet weak var pickerView: UIPickerView!
    
    
    
    var selectedType = "Food"
    var list = ["Food", "Travel"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.imageView.contentMode = .scaleAspectFill
        self.imageView.layer.masksToBounds = true
        self.selectCategoryView.layer.masksToBounds = true
        self.imageView.layer.borderColor = UIColor.lightGray.cgColor
        self.imageView.layer.borderWidth = 0.2
        self.imageView.layer.cornerRadius = 5
        
        self.selectCategoryView.layer.borderColor = UIColor.lightGray.cgColor
        self.selectCategoryView.layer.borderWidth = 0.2
        self.selectCategoryView.layer.cornerRadius = 5
        self.selectCategoryView.layer.cornerRadius = 5
        //self.selectCategoryView.layer.shadowColor = UIColor.lightGray.cgColor
        self.imageView.image = scannedImage
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(self.saveBillDetails(_:)))
        // Do any additional setup after loading the view.
    }
    

    @objc func saveBillDetails(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "BillsCategoryTableVC")
        self.navigationController?.pushViewController(controller, animated: true)
        billDetailsArray[billDetailsArray.count - 1].updateValue(selectedType, forKey: "type")
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func addMoreDetails(_ sender: Any) {
        UIView.transition(with: self.selectCategoryView, duration: 0.3, options: .showHideTransitionViews, animations: {
            self.selectCategoryView.isHidden = false
        }, completion: nil)
        
    }
    
    public func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }

    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{

        return list.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {

        self.view.endEditing(true)
        return list[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedType = self.list[row]
        selectedType = self.list[row]
    }
    
}
