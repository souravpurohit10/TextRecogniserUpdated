//
//  BillsCategoryTableVC.swift
//  TextDetectionPOC
//
//  Created by Sourav Purohit on 19/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import UIKit
var gArray = [[String: String]]()
class BillsCategoryTableVC: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var categoryTableView: UITableView!
    var billCategory = ["Food","Travel"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.billCategory.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellIdentifer")!
        cell.textLabel?.text = billCategory[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "ImageProcessedTableVC")
        self.navigationController?.pushViewController(controller, animated: true)
        gArray = billDetailsArray.filter{$0["type"] == billCategory[indexPath.row]}
    }
}
